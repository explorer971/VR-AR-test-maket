// owl-corousel Слайдер
$(".owl-carousel").owlCarousel({
  loop: true,
  nav: true,
  items: 6,
  margin: 79,
  autoplay: false,
  responsive: {
    0:{
      items:1
    },
    420:{
      items:2
    },
    768:{
      items:4
    },
    1224:{
      items:5
    },
    1500:{
      items:6
    }
  },
});

// мобильное меню
new Vue ({
  el: '#app',
  data: {
    show: false,
  },
});